import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int excelente = 0;
        int ruim = 0;
        for (int i = 1; i <= 10; i++) {
            System.out.println("Entrevistado " + i);
            System.out.print("Digite o nome: ");
            String nome = scanner.nextLine();
            System.out.print("Digite a idade: ");
            int idade = scanner.nextInt();
            System.out.print("Digite a opinião (1-EXCELENTE, 2-BOM, 3-RUIM): ");
            int opiniao = scanner.nextInt();
            scanner.nextLine(); // Consumir a nova linha

            if (opiniao == 1) {
                excelente++;
            } else if (opiniao == 3) {
                ruim++;
            }
        }

        System.out.println("Quantidade de respostas EXCELENTE: " + excelente);
        
        System.out.println("Quantidade de respostas RUIM: " + ruim);
    }
}